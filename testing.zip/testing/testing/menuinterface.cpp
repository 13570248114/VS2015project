#include "menuinterface.h"
#include "assetregister.h"
#include"custodian.h"
#include"computer.h"
#include"phone.h"
#include <limits>
#include"assetregister.h"
#include"television.h"
#include"HMD.h"
#include<cctype>


MenuInterface::MenuInterface(std::ostream &display, std::istream &input)
    : _display{display}, _input{input} {
}

void MenuInterface::displayMainMenu() const {
  _display << "What would you like to do?" << std::endl;
  _display << " (a)dd an asset" << std::endl;
  _display << " (d)ispose an asset" << std::endl;
  _display << " (u)pdate asset custodian or location" << std::endl;
  _display << "  add asset (m)aintenance record" << std::endl;
  _display << " (l)ist assets by type" << std::endl;
  _display << "  List assets by (c)ustodian" << std::endl;
  _display << " (f)ind asset" << std::endl;
  _display << " (q)uit" << std::endl;
}

char MenuInterface::getCharacterInput() const {
  char input;
  _input >> input;
  _input.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
  return input;
}

bool MenuInterface::processSelection(char selection) {
  switch (selection) {
  case 'a':
    addAsset();
    break;
  case 'd':
    disposeAsset();
    break;
  case 'u':
	updateAsset();
	break;
  case 'm':
	addMaintenance();
	break;
  case 'l':
    listAssetsByType();
    break;
  case 'c':
    listAssetsByCustodian();
    break;
  case 'f':
    findAsset();
    break;
  case 'q':
    return false;
  default:
    _display << "Sorry, \'" << selection << "\' is not a valid option, please try again."
             << std::endl;
  }
  return true;
}



void MenuInterface::addAsset() {
	// TODO: implement this member function.
	_display << "Add an asset" << std::endl;
	_display << " add a (c)omputer" << std::endl;
	_display << " add a (p)hone" << std::endl;
	_display << " add a (t)elevision" << std::endl;
	_display << " add a (H)MD" << std::endl;
	_display << " (b)ack to main menu" << std::endl;
	AssetRegister &am = AssetRegister::instance();
	char selection = getCharacterInput();
	switch (selection){
	    case 'c':{
			char selection2;
			std::string id, brand, model, serial, operatingSystem ;
			Date purchaseDate;
			bool laptop;
			char ch;
			double purchasePrice;
			do {
				_display << "please input the message of a computer:" << std::endl;
				_display << "id: brand: model: serial: operatingSystem: " << std::endl;
				_input >> id >> brand >> model >> serial >> operatingSystem;
				while (am.retrieveAsset(id) != nullptr) {
					_display << "ERROR : the id = " << id << " existed,please input a new id again:" << std::endl;
					_input >> id;
				}
				_display << "please input purchase price:" << std::endl;
				while ((purchasePrice = getNumberInput()) < 0)
					_display << "input ERROR,please input the purchase price again:" << std::endl;
				_display << "purchase date:" << std::endl;
				purchaseDate = inputDate();
				bool boolRewrite;
				do {
					boolRewrite = false;
					_display << "[1]Laptop computer\t[0]Desktop computers\nplease input 1 or 0" << std::endl;
					_input >> ch;
					if (ch > '1' || ch < '0') {
						_display << "unvalid input! please input again:" << std::endl;
						boolRewrite = true;
					}
				} while (boolRewrite);
				laptop = static_cast<bool> (ch - '0');
				_display << "all message of computer have been input,do you want to cancel and modify?" << std::endl;
				_display << "input 'N' to cancel ,input 'Y' to store the computer" << std::endl;
				selection2 = getCharacterInput();
			} while (selection2=='N');
			std::shared_ptr<Computer> computer = std::make_shared<Computer>(id, brand, model, purchasePrice, 
				                                                            purchaseDate, serial, operatingSystem, laptop);
			am.storeAsset(computer);
			displayAsset(computer);
			_display << "message of a computer has saved!\nplease return to main menu to complete the custodian and mainteance messages\n" 
				     << std::endl;
			break;
	    }
		case 'p':{
			char selection2;
			std::string id, brand, model, serial, operatingSystem, phoneNumber, billingIdentifier;
			double purchasePrice;
			Date purchaseDate;
			do {
				_display << "please input the message of a phone:" << std::endl;
				_display << "id: brand: model: serial: operatingSystem: phoneNumber: billingIdentifier:" << std::endl;
				_input >> id >> brand >> model >>  serial >> operatingSystem >> phoneNumber >> billingIdentifier;
				while (am.retrieveAsset(id) != nullptr) {
					_display << "ERROR : the id = " << id << " existed,please input a new id again:" << std::endl;
					_input >> id;
				}
				_display << "please input purchase price:" << std::endl;
				while((purchasePrice = getNumberInput()) < 0)
					_display << "input ERROR,please input the purchase price again:" << std::endl;
				_display << "purchase date:" << std::endl;
				purchaseDate = inputDate();
				_display << "all message of computer have been input,do you want to cancel and modify?" << std::endl;
				_display << "input 'N' to cancel ,input 'Y' to store the phone" << std::endl;
				selection2 = getCharacterInput();
			} while (selection2 == 'N');
			std::shared_ptr<Phone> phone = std::make_shared<Phone>(id, brand, model, purchasePrice, purchaseDate, serial,
				                           operatingSystem, billingIdentifier, phoneNumber);
			am.storeAsset(phone);
			displayAsset(phone);
			_display << "message of a phone has saved!\nplease return to main menu to complete the custodian and mainteance messages\n"
				     << std::endl;
			break;
		}
		case 't': {
			char selection2;
			std::string id, brand, model, serial, location;
			double purchasePrice;
			Date purchaseDate;
			do {
				_display << "please input the message of a television:" << std::endl;
				_display << "id: brand: model: serial: location" << std::endl;
				_input >> id >> brand >> model >>  serial >> location;
				while (am.retrieveAsset(id) != nullptr) {
					_display << "ERROR : the id = " << id << " existed,please input a new id again:" << std::endl;
					_input >> id;
				}
				_display << "please input purchase price:" << std::endl;
				while((purchasePrice = getNumberInput())< 0 )
					_display << "input ERROR,please input the purchase price again:" << std::endl;
				while (am.retrieveAsset(id) != nullptr) {
					_display << "ERROR : the id = " << id << "exist,please input a new id again:" << std::endl;
					_input >> id;
				}
				_display << "purchase date:" << std::endl;
				purchaseDate = inputDate();
				_display << "all message of computer have been input,do you want to cancel and modify?" << std::endl;
				_display << "input 'N' to cancel ,input 'Y' to store the television" << std::endl;
				selection2 = getCharacterInput();
			} while (selection2 == 'N');
			std::shared_ptr<Television> television = std::make_shared<Television>(id, brand, model, purchasePrice,
				                                     purchaseDate, serial, location);
			displayAsset(television);
			am.storeAsset(std::make_shared<Television>(id, brand, model, purchasePrice, purchaseDate, serial,
				location));
			_display << "message of a television has saved!\nplease return to main menu to complete the custodian and mainteance messages\n" 
				     << std::endl;
			break;
		}
		case 'H':{
			char selection2;
			std::string id, brand, model, serial;
			double purchasePrice;
			Date purchaseDate;
			do {
				_display << "please input the message of a HMD:" << std::endl;
				_display << "id: brand: model: serial " << std::endl;
				_input >> id >> brand >> model >> serial ;
				while (am.retrieveAsset(id) != nullptr) {
					_display << "ERROR : the id = " << id << " existed,please input a new id again:" << std::endl;
					_input >> id;
				}
				_display << "please input purchase price:" << std::endl;
				while((purchasePrice = getNumberInput()) < 0)
					_display << "input ERROR,please input the purchase price again:" << std::endl;
				while (am.retrieveAsset(id) != nullptr) {
					_display << "ERROR : the id = " << id << "exist,please input a new id again:" << std::endl;
					_input >> id;
				}
				_display << "purchase date:" << std::endl;
				purchaseDate = inputDate();
				_display << "all message of HMD have been input,do you want to cancel and modify?" << std::endl;
				_display << "input 'N' to cancel ,input 'Y' to store the television" << std::endl;
				selection2 = getCharacterInput();
			} while (selection2 == 'N');
			std::shared_ptr<HMD> hmd = std::make_shared<HMD>(id, brand, model, purchasePrice, purchaseDate, serial);
			am.storeAsset(hmd);
			displayAsset(hmd);
			_display << "message of a HMD has saved!\nplease return to main menu to complete the custodian and mainteance messages\n" 
				     << std::endl;
			break;
		}
		case 'b': {
			break;
		}
		default:
			_display << "Sorry, \'" << selection << "\' is not a valid option, please try again."
				     << std::endl;
	}
}

void MenuInterface::disposeAsset() {
  // TODO: implement this member function.
	bool rewrite=false;
	std::shared_ptr<Asset> asset = retrieveAsset();
	if (asset != nullptr&&asset->getDispose() == true)
		_display << "This asset has been displosed! It can't be displose again!" << std::endl;
	else {
		Date disposeDate;
		do {
			if (rewrite)
				_display << "the dispose date can't be earlier than the purchase date,please input again:" << std::endl;
			_display << "please input dispose date:" << std::endl;
			disposeDate = inputDate();
			rewrite = false;
			if (disposeDate.format2() < asset->purchaseDate().format2())
				rewrite = true;
		} while (rewrite);
		if (asset != nullptr) {
			asset->dispose(disposeDate);
			asset->setDispose(true);
		}
		_display << "displose success!\n" << std::endl;
	}
}

void MenuInterface::updateAsset() {
  // TODO: implement this member function.
	std::shared_ptr<Asset> asset = retrieveAsset();
	std::shared_ptr<Custodian> custodian = inputCustodian();
	asset->setCustodian(custodian);
	AssetRegister &am = AssetRegister::instance();
	am.stortCustodianMap(custodian->name(), asset->id());
	_display << "Custodian message haved saved!\n" << std::endl;
}

void MenuInterface::addMaintenance() {
  // TODO: implement this member function.
	std::shared_ptr<Asset> asset = retrieveAsset();
	std::string maintenancePersion;
	_display << "please input the maintenance person's name"<<std::endl;
	_input >> maintenancePersion;
	Date Timestamp=inputDate();
	asset->setMaintenanceRecord(Timestamp, maintenancePersion);
	_display << "Maintenance message haved saved!\n" << std::endl;
}

void MenuInterface::listAssetsByType() {
  // TODO: implement this member function.
	_display << "\nList asset by type" << std::endl;
	_display << "  List (a)ll assets" << std::endl;
	_display << "  List (c)omputers" << std::endl;
	_display << "  List (p)hones" << std::endl;
	_display << "  List (t)elevision" << std::endl;
	_display << "  List (H)MD" << std::endl;
	_display << "  (b)ack to main menu" << std::endl;

	AssetRegister &am = AssetRegister::instance();
	auto assets = am.getAssets();
	char selection = getCharacterInput();
	_display << "ID\tBrand\tModel\tPurchase Price\tPurchase Date\tserial" << std::endl;
	switch (selection) {
	case 'a':
		for (auto asset : assets) {
			auto assetPtr = asset.second;
			listAsset(assetPtr);
		}
		break;
	case 'c':
		for (auto asset : assets) {
			if (asset.second->type() == "Computer") {
				std::shared_ptr<Computer> computer = std::dynamic_pointer_cast<Computer>(asset.second);
				listAsset(computer);
			}
		}
		break;
	case 'p':
		for (auto asset : assets) {
			if (asset.second->type() == "Phone") {
				std::shared_ptr<Phone> phone = std::dynamic_pointer_cast<Phone>(asset.second);
				listAsset(phone);
			}
		}
		break;
	case 't':
		for (auto asset : assets) {
			if (asset.second->type() == "Television") {
				std::shared_ptr<Television> television = std::dynamic_pointer_cast<Television>(asset.second);
				listAsset(television);
			}
		}
		break;
	case 'H':
		for (auto asset : assets) {
			if (asset.second->type() == "HMD") {
				std::shared_ptr<HMD> hmd = std::dynamic_pointer_cast<HMD>(asset.second);
				listAsset(hmd);
			}
		}
	case 'b': {
		break;
	}
	default:
		_display << "Sorry, \'" << selection << "\' is not a valid option, please try again."
			<< std::endl;
	}
	_display << "\n" << std::endl;
}

void MenuInterface::listAssetsByCustodian() {
  // TODO: implement this member function.
	std::string name;
	std::vector<std::string> assetIdVector;
	_display << "please input the Custodian person name:" << std::endl;
	_input >> name;
	AssetRegister &am = AssetRegister::instance();
	assetIdVector = am.CustodianMapId(name);
	if (!assetIdVector.empty()) {
		_display << "ID\tBrand\tModel\tPurchase Price\tPurchase Date\tserial" << std::endl;
		for (auto assetId : assetIdVector) {
			auto assetPtr = am.retrieveAsset(assetId);
			_display << assetPtr->id() << "\t" << assetPtr->brand() << "\t" << assetPtr->model() << "\t"
				<< assetPtr->purchasePrice() << "\t\t" << assetPtr->purchaseDate().format()
				<< "\t" << assetPtr->serial() << std::endl;
		}
	}
	else
		_display << name << " isn't a custodian." << std::endl;
	_display << "\n" << std::endl;
}

void MenuInterface::findAsset() {
  // TODO: implement this member function.
	AssetRegister &am = AssetRegister::instance();
	auto assets = am.getAssets();
	std::shared_ptr<Asset> asset = findMenu();
	displayAsset(asset);
	_display << "\n" << std::endl;
}

Date MenuInterface::inputDate() {
	Date result,current;
	current = current.currentDate();
	bool rewrite2 = false;
	int day = 0, year = 0, months = 0;
	do {
		do {
			if (rewrite2)
				_display << "the input Date is unvalid, please input the valid Date��" << std::endl;
			_display << "please input the message of Date:(day[1-31] month[1-12] year[>1900])" << std::endl;
			day = static_cast<int> (getNumberInput());
			months = static_cast<int>(getNumberInput());
			year = static_cast<int>(getNumberInput());
			rewrite2 = day < 1 || months < 1 || year < 1;
		} while (rewrite2);
		Date::Month month = (Date::Month)(months-1);
		Date temp(day, month, year);
		result = temp;
		rewrite2 = !result.valid()||(result.format2()>current.format2());
	} while (rewrite2);
	return result;
}

std::shared_ptr<Custodian> MenuInterface::inputCustodian() {
	_display << "please input the message of Custodian" << std::endl;
	_display<<"name: department: phone: " << std::endl;
	std::string name, department, phone;
	_input >> name >> department >> phone;
	_display << "please input the Employment Start Date" << std::endl;
	Date employmentStartDate = inputDate();
	std::shared_ptr<Custodian> custodian= std::make_shared<Custodian>(name, department, phone, employmentStartDate);
	return custodian;
}

std::shared_ptr<Asset> MenuInterface::retrieveAsset() {
	bool rewrite = false;
	std::shared_ptr<Asset> asset;
	do {
		if (rewrite)
			_display << "the input id not exist!please input again!" << std::endl;
		_display << "please input the id of the asset" << std::endl;
		std::string id;
		_input >> id;
		AssetRegister &am = AssetRegister::instance();
		asset = am.retrieveAsset(id);
		if (asset == nullptr)
			rewrite = true;
		else
			rewrite = false;
	} while (rewrite);
	return asset;
}

std::shared_ptr<Asset> MenuInterface::retrieveAssetBySerial() {
	_display << "please input the serial of the asset" << std::endl;
	std::string serial;
	_input >> serial;
	AssetRegister &am = AssetRegister::instance();
	std::shared_ptr<Asset> asset = am.retrieveAssetBySerial(serial);
	return asset;
}

void MenuInterface::maintenanceDetail(std::shared_ptr<Asset> asset) {
	_display << "MenuInterface History for asset" << asset->id()<<std::endl;
	if (!asset->getMaintenanceRecord().empty())
		for (auto recode : asset->getMaintenanceRecord())
			_display << " - " << recode.timeStamp().format() << " by " 
			         << recode.maintenancePersonName() << std::endl;
	else {
		_display << "NO maintenance Rcode has been saved!" << std::endl;
	}
	_display << "(r)eturn to asset detail" << std::endl;
	_display << "(b)ack to main menu" << std::endl;
	char selection = getCharacterInput();
	switch (selection) {
	case 'r': {
		displayAsset(asset);
		break;
	}
	case 'b': {
		break;
	}
	default:
		_display << "Sorry, \'" << selection << "\' is not a valid option, please try again."
			<< std::endl;
	}
	_display << "\n" << std::endl;
}

void MenuInterface::custodianDetails(std::shared_ptr<Asset> asset) {
	if (asset->custodian()->name() == "undefined")
		_display << "ERROR : NO custodian message has been saved!" << std::endl;
	else {
		std::string Month[] = {
			"January" , "February" , "March" , "April" , "May" , "June" , "July ",
			"August" , "September" ,"October" , "November" ,"December"
		};
		_display << "custodian for asset" << asset->id() << std::endl;
		_display << "Name:\t\t\t" << asset->custodian()->name() << std::endl;
		_display << "Date of Employment:\t" << asset->custodian()->employmentStart().day() << " "
			<< Month[asset->custodian()->employmentStart().month()] << " "
			<< asset->custodian()->employmentStart().year() << std::endl;
		_display << "Depatrment:\t\t" << asset->custodian()->department() << std::endl;
	}
	_display << "(r)eturn to asset detail" << std::endl;
	_display << "(b)ack to main menu" << std::endl;
	char selection = getCharacterInput();
	switch (selection) {
	case 'r': {
		displayAsset(asset);
		break;
	}
	case 'b': {
		break;
	}
	default:
		_display << "Sorry, \'" << selection << "\' is not a valid option, please try again."
			<< std::endl;
	}
	_display << "\n" << std::endl;
}

std::shared_ptr<Asset> MenuInterface::findMenu() {
	_display << "Find asset" << std::endl;
	_display << " search by (a)sset id" << std::endl;
	_display << " search by (s)erial" << std::endl;
	_display << " (b)ack to main menu" << std::endl;
	char selection = getCharacterInput();
	switch (selection) {
	case 'a': {
		std::shared_ptr<Asset> asset = retrieveAsset();
		return asset;
	}
	case 's': {
		std::shared_ptr<Asset> asset = retrieveAssetBySerial();
		return asset;
	}
	case 'b': {
		return nullptr;
	}
	default:
		_display << "Sorry, \'" << selection << "\' is not a valid option, please try again."
			<< std::endl;
		return nullptr;
	}
	_display << "\n" << std::endl;
}

void MenuInterface::displayAsset(std::shared_ptr<Asset> asset) {
	Date currentDay;
	currentDay = currentDay.currentDate();
	if (asset == nullptr)
		_display << "the asset not exist!" << std::endl;
	else {
		_display << "\nAsset ID:\t\t" << asset->id() << std::endl;
		_display << "Brand:\t\t\t" << asset->brand() << std::endl;
		_display << "Model:\t\t\t" << asset->model() << std::endl;
		_display << "Purchase Price:\t\t$" << asset->purchasePrice() << std::endl;
		_display << "Purchase Date:\t\t" << asset->purchaseDate().format() << std::endl;
		if (!asset->getDispose()) {

			switch (asset->type()[0]) {
			case 'C': {
				std::shared_ptr<Computer> computer = std::dynamic_pointer_cast<Computer>(asset);
				displayDepreciated(computer, currentDay);
				_display << "Serial Number:\t\t" << computer->serial() << std::endl;
				_display << "Network Identifier:\t" << computer->networkIdentifier() << std::endl;
				_display << "Operating System:\t" << computer->operatingSystem() << std::endl;
				_display << "Custodian:\t\t" << computer->custodian()->name() << std::endl;
				break;
			}
			case 'P': {
				std::shared_ptr<Phone> phone = std::dynamic_pointer_cast<Phone>(asset);
				displayDepreciated(phone, currentDay);
				_display << "Serial Number:\t\t" << phone->serial() << std::endl;
				_display << "Phone Number:\t\t" << phone->phoneNumber() << std::endl;
				_display << "Operating System:\t" << phone->operatingSystem() << std::endl;
				_display << "Billing Identifier:\t" << phone->billingIdentifier() << std::endl;
				_display << "Custodian:\t\t" << phone->custodian()->name() << std::endl;
				break;
			}
			case 'T': {
				std::shared_ptr<Television> television = std::dynamic_pointer_cast<Television>(asset);
				displayDepreciated(television, currentDay);
				_display << "Serial Number:\t\t" << television->serial() << std::endl;
				_display << "Location:\t\t" << television->location() << std::endl;
				break;
			}
			case 'H': {
				std::shared_ptr<HMD> hmd = std::dynamic_pointer_cast<HMD>(asset);
				displayDepreciated(hmd, currentDay);
				_display << "Serial Number:\t\t" << hmd->serial() << std::endl;
			}
			}
			if (!asset->getMaintenanceRecord().empty())
				_display << "Last Maintenance:\t" << asset->getMaintenanceRecord().back().timeStamp().format()
				<< " by " << asset->getMaintenanceRecord().back().maintenancePersonName()<<"\n" << std::endl;
			_display << " (c)ustodian details" << std::endl;
		}
		else {
			_display << "Disposal Date\t\t" << asset->disposalDate().format() << std::endl;
			double value = asset->purchasePrice() - asset->calculateDepreciation(asset->disposalDate());
			value = value < 0 ? 0 : value;
			_display << "Depreciated Value:\t$" << value << " ( at displosal )" << std::endl;
			if (!asset->getMaintenanceRecord().empty())
				_display << "Last Maintenance:\t" << asset->getMaintenanceRecord().back().timeStamp().format()
				<< " by " << asset->getMaintenanceRecord().back().maintenancePersonName() << "\n" << std::endl;
		}
		_display << " (m)aintenance history" << std::endl;
		_display << " (b)ack to main menu" << std::endl;
		char selection2 = getCharacterInput();
		switch (selection2) {
		case 'c':
			custodianDetails(asset);
			break;
		case 'm':
			maintenanceDetail(asset);
			break;
		case 'b':
			break;
		}
	}
	_display << "\n" << std::endl;
}

double MenuInterface::getNumberInput() {
	std::string num;
	_input >> num;
	bool isdouble = false;
	std::string::size_type i = 0;
	while (num[i] == ' '&&i<num.length())
		++i;
	num = num.substr(i, num.length() - i);
	if (num[0] == '.')
		return -1;
	i = 0;
	while (num[i] != ' '&&i<num.length())
		++i;
	num = num.substr(0, i);
	for (auto number : num) {
		if (number != '.' && !isdigit(number))
			return -1;
		if (number = '.')
			isdouble = true;
	}
	if (isdouble)
		return std::stod(num);
	else
		return std::stoi(num);
	return 0;

}

void MenuInterface::displayDepreciated(std::shared_ptr<Asset> asset,Date currentDay)
{
	double value = asset->purchasePrice() - asset->calculateDepreciation(currentDay);
	if (value < 0)
		value = 0;
	_display << "Depreciated Value:\t$" << value << " (depreciation of $" << asset->calculateDepreciation(currentDay)
		<< " at " << currentDay.format() << ")" << std::endl;
}

void MenuInterface::listAsset(std::shared_ptr<Asset> asset) {
	_display << asset->id() << "\t" << asset->brand() << "\t" << asset->model() << "\t"
		<< asset->purchasePrice() << "\t\t" << asset->purchaseDate().format()
		<< "\t" << asset->serial() << std::endl;
}


