#include "computer.h"

Computer::Computer(const std::string &id, const std::string &brand, const std::string &model,
	      const double purchasePrice, const Date &purchaseDate, const std::string &serial,
	      const std::string &operatingSystem,const bool &labtop)
	: Asset(id, brand, model, purchasePrice, purchaseDate, serial), _labtop(labtop) ,
	  _operatingSystem(operatingSystem){
	_type = std::string("Computer");
	if (labtop)
		_effectiveLifespan = 3;
	else
		_effectiveLifespan = 4;
}


const std::string &Computer::operatingSystem() const {
	return _operatingSystem;
}

const std::string &Computer::networkIdentifier() const {
	return _networkIdentifier;
}

void Computer::setOperatingSystem(std::string os) {
	_operatingSystem = os;
}

