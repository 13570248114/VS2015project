#ifndef GRAPH_H
#define GRAPH_H
#include"readData.h"

typedef struct {
	urlList List_of_Urls;
	int num_of_vertex;
	int** adjmatrix;
}Graph;

typedef Graph* graph;

graph init_graph();
void Pgraph(graph g);
graph link_graph(graph g);
int getVertexNum(urlList List_of_Urls, char* url);
int outDegree(graph g, int vertex);
#endif // !GRAPH_H

