#include"readData.h"
#include<stdlib.h>
#include<string.h>


urlList insertNode(urlList List_of_Urls, char *url)
{
	urlNode* node = (urlNode*)malloc(sizeof(urlNode));
	strcpy(node->url, url);
	node->next = NULL;

	if (List_of_Urls == NULL) 
	{
		node->vertex = 0;
		List_of_Urls = (urlList)malloc(sizeof(urlL));
		List_of_Urls->tail = List_of_Urls->head = node;
		List_of_Urls->num_of_node = 1;
	}
	else
	{
		node->vertex = List_of_Urls->tail->vertex + 1;
		List_of_Urls->tail->next = node;
		List_of_Urls->tail = node;
		++List_of_Urls->num_of_node;
	}
	return List_of_Urls;
}

void Plist(urlList List_of_Urls)
{
	urlNode* node = List_of_Urls->head;
	while (node != NULL)
		printf("%s -- %d\n", node->url, node->vertex), node=node->next; 
	printf("\n");
}

urlList GetCollection()
{
	urlList List_of_Urls = NULL;
	FILE *fp;
	if ((fp = fopen("collection.txt","r") )== NULL)               //�򿪲������ɹ�
	{
		printf("Collection.txt can not be opened.\n");
		exit(1);                                                             //���������ִ��
	}

	char url[20];
	while (fscanf(fp, "%s", url) > 0)
	{
		List_of_Urls = insertNode(List_of_Urls, url);
	}
	fclose(fp);
	return List_of_Urls;
}

char* map_vertex_to_url(urlList List_of_Urls, int vertex)
{
	urlNode* node = List_of_Urls->head;
	while (vertex--)
		node = node->next;
	return node->url;
}



