#ifndef READDATA_H
#define READDATA_H
#include<stdio.h>

typedef struct urlNode {
	char url[20];
	int vertex;
	struct urlNode *next;
}urlNode;

typedef struct urlL {
	urlNode* head;
	urlNode* tail;
	int num_of_node;
}urlL;

typedef urlL* urlList;


urlList insertNode(urlList List_of_Urls, char *url);
urlList GetCollection();
void Plist(urlList List_of_Urls);
char* map_vertex_to_url(urlList List_of_Urls, int vertex);

#endif // !READDATA_H
