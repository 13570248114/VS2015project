#include"ReadWords.h"
#include<iostream>
#include<cstdlib>
#include<cctype>
using namespace std;

ReadWords::ReadWords(const char *filename)
{
	wordfile.open(filename);
	if (wordfile.fail())
	{
		cout << filename << "open error !" << endl;
		exit(1);
	}
}