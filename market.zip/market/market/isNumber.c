#include"head.h"

int isNumber(char ch) {
	if (ch >= '0'&&ch <= '9')
		return TRUE;
	else
		return FALSE;
}