#ifndef REDUCEGCD_H
#define REDUCEGCD_H
#include"ReduceGeneric.h"
class ReduceGCD :public ReduceGeneric {
private:
	int binaryOperator(int x, int y);
};
#endif // !REDUCEGCD_H


