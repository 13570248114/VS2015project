#include"MapSquare.h"

int MapSquare::f(int x) {
	return x*x;
}