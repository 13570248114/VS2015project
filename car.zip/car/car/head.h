#ifndef HEAD_H
#define HEAD_H
#include<iostream>
#include<string>
#include<vector>
#include<iterator>
#include<conio.h>
#include<stdio.h>
using namespace std;
#endif
