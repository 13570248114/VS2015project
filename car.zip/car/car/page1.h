#ifndef PAGE1_H
#define PAGE1_H

#include "head.h"
#include "car.h"
class page1 {
private:
	vector<car> car_message;
public:
	page1() {};
	void display();
	void add();
	int del(int i);
	void find(string car_number);
	int change(string car_number);
	void menu();
};

#endif
