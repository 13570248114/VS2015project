#include"MapAbsoluteValue .h"

int MapAbsoluteValue::f(int x) {
	return x > 0 ? x : -x;                                        //���ؾ���ֵ
}