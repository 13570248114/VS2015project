#include "MapTriple.h"

int MapTriple::f(int x) {
	return 3 * x;
}