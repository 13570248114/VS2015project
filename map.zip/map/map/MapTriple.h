#ifndef MAPTRIPLE_H
#define MAPTRIPLE_H

#include "MapGeneric.h"

class MapTriple :public MapGeneric {
private:
	int f(int x);
};
#endif // !MAPTRIPLE_H

