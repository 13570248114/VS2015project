#include"head.h"
#define getNum(ch) (ch-'0')
int main() {
	char t[20] = "2017:02:29:23:11";
	printf("%d\n",checkTime(t));
}