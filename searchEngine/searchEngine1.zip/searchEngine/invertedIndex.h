#ifndef INVERTEDINDEX_H
#define INVERTEDINDEX_H
#include"readData.h"
typedef struct BST_node
{
	char word[20];
	urlList Urls;
	struct BST_node* left;
	struct BST_node* right;
}BST_node;

typedef BST_node* BST;

BST insertBST(BST root, char* word, char* url);
BST makeBST(BST root);

#endif // !INVERTEDINDEX_H

