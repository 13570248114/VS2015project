#include"invertedIndex.h"
#include<stdio.h>
#include<string.h>
#include<stdlib.h>

BST makeBST(BST root)
{
	urlList List_of_Urls = GetCollection();
	urlNode* node = List_of_Urls->head;
	char word[20];
	char *t = ".txt";
	FILE *fp;
	int num = 0;
	while (node != NULL)
	{
		char file[20];
		num = 0;
		strcpy(file, node->url);
		strcat(file, t);
		if ((fp = fopen(file, "r")) == NULL)               //�򿪲������ɹ�
		{
			printf("%s can not be opened.\n", file);
			exit(1);                                                             //���������ִ��
		}

		while (fscanf(fp, "%s", word) > 0)
		{
			if (num < 3)
			{
				num++;
			}
			else
			{
				if (strcmp(word, "#start") == 0 || strcmp(word, "Section-1") == 0 || strcmp(word, "#end") == 0 || strcmp(word, "Section-2") == 0)
					continue;
				else
				{
					return;
				}
			}
		}

	}
}

BST insertBST(BST root, char* word, char* url)
{
	if (root == NULL)
	{
		BST root = (BST)malloc(sizeof(BST_node));
		root->left = root->right = NULL;
		strcpy(root->word, word);
	}
}