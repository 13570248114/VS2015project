

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "listIteratorInt.h"

char *myitoa(int *i){
  char *str;
  if(i == NULL){ return "NULL";}
  
  if ((str = malloc(20*sizeof(char))) == NULL) { return "Error";}
  sprintf(str, "%d", *i);
  return str;
}

/* ------ Helper functions for Operations on ADT ---------
*/

void adddsp(IteratorInt it, int v){
  int result = add(it , v); 
  printf("add %d, returns %d \n", v, result );
   
}
void nextdsp(IteratorInt it){
  printf("next, returns %s \n", myitoa(next(it)) ) ;   
}
void findnextdsp(IteratorInt it,int v) {
	printf("findNext, returns %s \n", myitoa(findNext(it,v)));
}
void prevdsp(IteratorInt it){
  printf("previous, returns %s \n", myitoa(previous(it)) );   
}
void findprevdsp(IteratorInt it,int v) {
	printf("findPrevious, returns %s \n", myitoa(findPrevious(it,v)));
}
void deletedsp(IteratorInt it){
  printf("delete, returns %d \n", deleteElm(it)) ;   
}

void setdsp(IteratorInt it, int v) {
	int result = set(it, v);
	printf("set %d, returns %d \n", v, result);

}

void printAll(IteratorInt it)
{
	reset(it);
	printf("\nprintf all:\n");
	while (hasNext(it))
		nextdsp(it);
}

int main(int argc, char *argv[]) {
  
	  int TestNo = 2;
	  IteratorInt it = IteratorIntNew();
	   int a[5] = { 25, 14, 32, 53 , 8  };
	  
	   if (TestNo == 1) {                    //������ֻ��һ��Ԫ�صĲ���
		   adddsp(it, a[0]);
		   deletedsp(it);
		   nextdsp(it);
		   prevdsp(it);
		   deletedsp(it);
		   adddsp(it, a[0]);
		   prevdsp(it);
		   setdsp(it, 100);
		   printf("hasnext: %d\n", hasNext(it));
		   printf("hasprev: %d\n", hasPrevious(it));
		   prevdsp(it);
		   setdsp(it, 100);
		   findnextdsp(it, a[0]);
		   findprevdsp(it, a[0]);
		   findprevdsp(it, 14);
	   }
	   else
	   {
		   for(int i=0;i<5;i++)
			   adddsp(it, a[i]);
		   printAll(it);                    //�α��ѵ�����
		   nextdsp(it);  

		   prevdsp(it);
		   prevdsp(it);
		   deletedsp(it);
		   printAll(it);                    //�α��ѵ�����

		   prevdsp(it);
		   prevdsp(it);
		   adddsp(it, 14);
		   printAll(it);                    //�α��ѵ�����

		   reset(it);
		   findnextdsp(it, 14);
		   findnextdsp(it, 14);
		   findnextdsp(it, 14);
	   }


	
	   /*
	  printf(" --- --- --- --- --- \n" );

	  
	  if(TestNo == 1) { 
		
	    prevdsp(it);
	    prevdsp(it);
	    prevdsp(it);
		deletedsp(it);
		deletedsp(it);
		adddsp(it, 20);
		//prevdsp(it);
		nextdsp(it);
		//printAll(it);
		reset(it);
		printf("%d\n", hasPrevious(it));
		nextdsp(it);
		set(it, 100);
		prevdsp(it);
		printAll(it);
		reset(it);
		findnextdsp(it, 32);
		findprevdsp(it, 53);
		freeIt(it);
	  }
	  else if(TestNo == 2) {
	    prevdsp(it);
	    prevdsp(it);
	    prevdsp(it);   
	    nextdsp(it);
	    nextdsp(it);
	  }
	  else if(TestNo == 3) { 
	    prevdsp(it);
	    prevdsp(it);
	    prevdsp(it);
	    deletedsp(it);
	    nextdsp(it);

	    prevdsp(it);
	    prevdsp(it);
	  }
	  */

  	return EXIT_SUCCESS;

}
