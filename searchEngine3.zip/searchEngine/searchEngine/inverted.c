#include"BST.h"
#include<stdio.h>
#include<string.h>
#include<stdlib.h>

char* normalise_word(char* word)
{
	int len = strlen(word);
	if (word[len - 1] == '.' || word[len - 1] == ',' || word[len - 1] == ';' || word[len - 1] == '?')          //ȥ�����ʺ�����ַ�
	{
		word[len - 1] = '\0';
		--len;
	}
	for (int i = 0;i < len;i++)                                                   //�����ʻ�ΪСд
		if (word[i] >= 'A'&&word[i] <= 'Z')
			word[i] += 'a' - 'A';
	return word;
}

int main()
{
	BST root = makeBST(NULL);
	FILE *fp;
	if ((fp = fopen("invertedIndex.txt", "w")) == NULL)               //�򿪲������ɹ�
	{
		printf("pagerankList.txt can not be opened.\n");
		exit(1);                                                             //���������ִ��
	}
	PrintBST(root,fp);
	destoryBST(root);
}