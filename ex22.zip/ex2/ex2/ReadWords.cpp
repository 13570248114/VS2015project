#include"ReadWords.h"
#include<iostream>
#include<cstdlib>
#include<cctype>
using namespace std;

ReadWords::ReadWords(const char *filename)
{
	wordfile.open(filename);
	if (wordfile.fail())
	{
		cout << filename << "open error !" << endl;
		exit(1);
	}
}

bool ReadWords::isNextWord()
{
	char c;
	wordfile >> c;
	if (c == EOF)
		return false;
	else
	{
		wordfile.seekg(-1, ios::cur);
		return true;
	}
}

string ReadWords::getNextWord()
{
	char c;
	nextword.clear();
	while (isNextWord())
	{
		do
			wordfile >> c;
		while (!isalpha(c)&&nextword.empty());

		if (c !=' ')
		{
			c = tolower(c);
			nextword += c;
		}
		else
		{
			int i;
			for (i = nextword.length() - 1;i >= 0;i--)
				if (isalpha(nextword[i]))
					break;
			nextword = nextword.substr(0, i + 1);
			return nextword;
		}
	}
}

void  ReadWords::close()
{
	wordfile.close();
}